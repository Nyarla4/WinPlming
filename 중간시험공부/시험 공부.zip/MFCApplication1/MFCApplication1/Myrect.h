#pragma once
class Rect
{
public:
	Rect();
	~Rect();

	CPoint r_start;
	CPoint r_end;
private:

};