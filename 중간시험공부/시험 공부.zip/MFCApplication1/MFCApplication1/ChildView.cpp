
// ChildView.cpp : CChildView Ŭ������ ����
//

#include "stdafx.h"
#include "MFCApplication1.h"
#include "ChildView.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// CChildView

CChildView::CChildView()
{
	rect_num = 0;
	c_rect[rect_num] = (RGB(0, 255, 255));
}

CChildView::~CChildView()
{
}


BEGIN_MESSAGE_MAP(CChildView, CWnd)
	ON_WM_PAINT()
	ON_WM_LBUTTONDOWN()
	ON_WM_LBUTTONUP()
	ON_WM_KEYDOWN()
	ON_WM_MOUSEHOVER()
    ON_WM_TIMER ()
END_MESSAGE_MAP()



// CChildView �޽��� ó����

BOOL CChildView::PreCreateWindow(CREATESTRUCT& cs) 
{
	if (!CWnd::PreCreateWindow(cs))
		return FALSE;

	cs.dwExStyle |= WS_EX_CLIENTEDGE;
	cs.style &= ~WS_BORDER;
	cs.lpszClass = AfxRegisterWndClass(CS_HREDRAW|CS_VREDRAW|CS_DBLCLKS, 
		::LoadCursor(NULL, IDC_ARROW), reinterpret_cast<HBRUSH>(COLOR_WINDOW+1), NULL);

	return TRUE;
}

void CChildView::OnPaint() 
{
	CPaintDC dc(this); 
	/*CBrush brush(c_rect_color[rect_num]);
	dc.SelectObject(&brush);
	for (int i = 0; i < rect_num; i++)
	{
		dc.Rectangle(rect_color[i].r_start.x, rect_color[i].r_start.y, rect_color[i].r_end.x, rect_color[i].r_end.y);
	}*/
	//dc.Ellipse(mouse.x - 10, mouse.y - 10, mouse.x + 10, mouse.y + 10);
    for (int i = 0; i < rect_num; i++)
    {
        //dc.DrawText (m_str[i], m_rect[i], )
    }
    /*CBitmap bitmap;
    bitmap.LoadBitmap (IDB_BITMAP1);
    CBrush bit_brush (&bitmap);
    dc.SelectObject (&bit_brush);
    CRect rec;
    GetClientRect (&rec);
    BITMAP bmpInfo;
    bitmap.GetBitmap (&bmpInfo);
    CDC memDc;
    memDc.CreateCompatibleDC (&dc);
    memDc.SelectObject (&bitmap);
    if (rec.bottom > rec.right)
    {

    }
    dc.BitBlt (rec.right / 2 - bmpInfo.bmWidth/2, rec.bottom / 2 - bmpInfo.bmHeight/2,
    bmpInfo.bmWidth, bmpInfo.bmHeight,
    &memDc, 0, 0, SRCCOPY);*/
}



void CChildView::OnLButtonDown(UINT nFlags, CPoint point)
{
	//rect_color[rect_num].r_start = point;
	CWnd::OnLButtonDown(nFlags, point);
}


void CChildView::OnLButtonUp(UINT nFlags, CPoint point)
{
	/*rect_color[rect_num].r_end = point;
	rect_num++;*/
	Invalidate();
	CWnd::OnLButtonUp(nFlags, point);
}


void CChildView::OnKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags)
{
	/*if (nChar == 'R')
		c_rect[rect_num] = (RGB(255, 0, 0));
	if (nChar == 'G')
		c_rect[rect_num] = (RGB(0, 255, 0));
	if (nChar == 'B')
		c_rect[rect_num] = (RGB(0, 0, 255));*/
	Invalidate();
	CWnd::OnKeyDown(nChar, nRepCnt, nFlags);
}


void CChildView::OnMouseHover(UINT nFlags, CPoint point)
{
	mouse = point;
	Invalidate();
	CWnd::OnMouseHover(nFlags, point);
}


void CChildView::OnTimer (UINT_PTR nIDEvent)
{
    if (nIDEvent == 0)
    {

    }

    CWnd::OnTimer (nIDEvent);
}
