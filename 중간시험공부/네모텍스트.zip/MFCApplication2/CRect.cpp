#include"stdafx.h"
#include"CRect.h"

CRect::CRect()
{
}

CRect::~CRect()
{
}