#pragma once
class CRect
{
public:
	CRect();
	~CRect();

	CPoint rect_start;
	CPoint rect_end;
private:

};