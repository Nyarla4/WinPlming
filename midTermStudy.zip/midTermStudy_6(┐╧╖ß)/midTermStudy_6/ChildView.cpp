
// ChildView.cpp : CChildView Ŭ������ ����
//

#include "stdafx.h"
#include "midTermStudy_6.h"
#include "ChildView.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// CChildView

CChildView::CChildView()
{
	size = 0;
	NumColor = 0;
	dn = 0;
	ds = 10;
}

CChildView::~CChildView()
{
}


BEGIN_MESSAGE_MAP(CChildView, CWnd)
	ON_WM_PAINT()
	ON_WM_MOUSEMOVE()
	ON_WM_TIMER()
	ON_WM_CREATE()
END_MESSAGE_MAP()



// CChildView �޽��� ó����

BOOL CChildView::PreCreateWindow(CREATESTRUCT& cs) 
{
	if (!CWnd::PreCreateWindow(cs))
		return FALSE;

	cs.dwExStyle |= WS_EX_CLIENTEDGE;
	cs.style &= ~WS_BORDER;
	cs.lpszClass = AfxRegisterWndClass(CS_HREDRAW|CS_VREDRAW|CS_DBLCLKS, 
		::LoadCursor(NULL, IDC_ARROW), reinterpret_cast<HBRUSH>(COLOR_WINDOW+1), NULL);

	return TRUE;
}

void CChildView::OnPaint() 
{
	CPaintDC dc(this);
	color = (RGB(NumColor, NumColor, NumColor));
	CBrush brush(color);
	dc.SelectObject(&brush);
	dc.Ellipse(mouse.x - size, mouse.y - size, mouse.x + size, mouse.y + size);
}



void CChildView::OnMouseMove(UINT nFlags, CPoint point)
{
	mouse = point;
	Invalidate();
	CWnd::OnMouseMove(nFlags, point);
}


void CChildView::OnTimer(UINT_PTR nIDEvent)
{
	// TODO: ���⿡ �޽��� ó���� �ڵ带 �߰� ��/�Ǵ� �⺻���� ȣ���մϴ�.
	if (nIDEvent == 0)
	{
		if (size == 50)
			ds = -10;
		if (size == 0)
			ds = 10;
		size += ds;
	}
	if (nIDEvent == 1)
	{
		if (NumColor == 255)
			dn = -10;
		if (NumColor == 0)
			dn = 10;
		NumColor += dn;
	}
	Invalidate();
	CWnd::OnTimer(nIDEvent);
}


int CChildView::OnCreate(LPCREATESTRUCT lpCreateStruct)
{
	if (CWnd::OnCreate(lpCreateStruct) == -1)
		return -1;
	SetTimer(0, 40, NULL);
	SetTimer(1, 30, NULL);
	// TODO:  ���⿡ Ư��ȭ�� �ۼ� �ڵ带 �߰��մϴ�.

	return 0;
}
