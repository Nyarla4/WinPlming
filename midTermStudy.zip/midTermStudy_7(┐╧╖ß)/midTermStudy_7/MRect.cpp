#include"stdafx.h"
#include"MRect.h"

m_rect::m_rect()
{
}

m_rect::~m_rect()
{
}