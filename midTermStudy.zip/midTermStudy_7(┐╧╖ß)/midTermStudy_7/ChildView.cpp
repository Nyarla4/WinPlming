
// ChildView.cpp : CChildView Ŭ������ ����
//

#include "stdafx.h"
#include "midTermStudy_7.h"
#include "ChildView.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// CChildView

CChildView::CChildView()
{
	pt.x = pt.y = 10;
	v.x = v.y = 0;
}

CChildView::~CChildView()
{
}


BEGIN_MESSAGE_MAP(CChildView, CWnd)
	ON_WM_PAINT()
	ON_WM_TIMER()
	ON_WM_CREATE()
	ON_WM_KEYDOWN()
	ON_WM_LBUTTONDOWN()
END_MESSAGE_MAP()



// CChildView �޽��� ó����

BOOL CChildView::PreCreateWindow(CREATESTRUCT& cs) 
{
	if (!CWnd::PreCreateWindow(cs))
		return FALSE;

	cs.dwExStyle |= WS_EX_CLIENTEDGE;
	cs.style &= ~WS_BORDER;
	cs.lpszClass = AfxRegisterWndClass(CS_HREDRAW|CS_VREDRAW|CS_DBLCLKS, 
		::LoadCursor(NULL, IDC_ARROW), reinterpret_cast<HBRUSH>(COLOR_WINDOW+1), NULL);

	return TRUE;
}

void CChildView::OnPaint() 
{
	CPaintDC dc(this);

	dc.Rectangle(pt.x, pt.y, pt.x+50, pt.y+50);
}



void CChildView::OnTimer(UINT_PTR nIDEvent)
{
	CRect rect;
	GetClientRect(&rect);
	if (nIDEvent == 0)
	{
		if (pt.y >= rect.top)
			v.y *= -1;
		if (pt.y + 50 <= rect.bottom)
			v.y *= -1;
		if (pt.x <= rect.left)
			v.x *= -1;
		if (pt.x + 50 >= rect.right)
			v.x *= -1;
		pt += v;
	}
	Invalidate();
	CWnd::OnTimer(nIDEvent);
}


int CChildView::OnCreate(LPCREATESTRUCT lpCreateStruct)
{
	if (CWnd::OnCreate(lpCreateStruct) == -1)
		return -1;
	SetTimer(0, 30, NULL);

	return 0;
}


void CChildView::OnKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags)
{
	if (nChar == VK_LEFT)
	{
		v.y = 0;
		v.x = -10;
	}
	if (nChar == VK_RIGHT)
	{
		v.y = 0;
		v.x = 10;
	}
	if (nChar == VK_UP)
	{
		v.x = 0;
		v.y = -10;
	}
	if (nChar == VK_DOWN)
	{
		v.x = 0;
		v.y = 10;
	}
	CWnd::OnKeyDown(nChar, nRepCnt, nFlags);
}


void CChildView::OnLButtonDown(UINT nFlags, CPoint point)
{
	int X = (pt.x + 25 - point.x)/-10;
	int Y = (pt.y + 25 - point.y)/-10;
	v.x = X;
	v.y = Y;
	
	CWnd::OnLButtonDown(nFlags, point);
}
