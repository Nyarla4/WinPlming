#pragma once
class DRect
{
public:
	DRect();
	~DRect();

	CPoint start;
	CPoint end;
private:

};