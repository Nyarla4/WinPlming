
// ChildView.cpp : CChildView Ŭ������ ����
//

#include "stdafx.h"
#include "midTermStudy.h"
#include "ChildView.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// CChildView

CChildView::CChildView()
{
	dot_num = 0;
	LBD = false;
	RBD = false;
	d_dot = 0;
}

CChildView::~CChildView()
{
}


BEGIN_MESSAGE_MAP(CChildView, CWnd)
	ON_WM_PAINT()
	ON_WM_LBUTTONDOWN()
	ON_WM_LBUTTONUP()
	ON_WM_RBUTTONDOWN()
	ON_WM_RBUTTONUP()
	ON_WM_MOUSEMOVE()
END_MESSAGE_MAP()



// CChildView �޽��� ó����

BOOL CChildView::PreCreateWindow(CREATESTRUCT& cs) 
{
	if (!CWnd::PreCreateWindow(cs))
		return FALSE;

	cs.dwExStyle |= WS_EX_CLIENTEDGE;
	cs.style &= ~WS_BORDER;
	cs.lpszClass = AfxRegisterWndClass(CS_HREDRAW|CS_VREDRAW|CS_DBLCLKS, 
		::LoadCursor(NULL, IDC_ARROW), reinterpret_cast<HBRUSH>(COLOR_WINDOW+1), NULL);

	return TRUE;
}

void CChildView::OnPaint() 
{
	CPaintDC dc(this);

	for (int i = 0; i < dot_num; i++)
	{
		dc.SetPixel(dot[i], RGB(color_[i], color_[i], color_[i]));
	}
	if(RBD)
		dc.Rectangle(dRect.start.x, dRect.start.y, dRect.end.x, dRect.end.y);
	CString str;
	str.Format(_T("�� ���� : %d"),
		dot_num - d_dot);
	dc.TextOut(100, 100, str);
}



void CChildView::OnLButtonDown(UINT nFlags, CPoint point)
{
	LBD = true;
	dot[dot_num] = point;
	dot_num++;
	Invalidate();
	CWnd::OnLButtonDown(nFlags, point);
}


void CChildView::OnLButtonUp(UINT nFlags, CPoint point)
{
	LBD = false;
	dot[dot_num] = point;
	dot_num++;
	Invalidate();
	CWnd::OnLButtonUp(nFlags, point);
}


void CChildView::OnRButtonDown(UINT nFlags, CPoint point)
{
	RBD = true;
	dRect.start = point;
	CWnd::OnRButtonDown(nFlags, point);
}


void CChildView::OnRButtonUp(UINT nFlags, CPoint point)
{
	RBD = false;
	dRect.end = point;
	for (int i = 0; i < dot_num; i++)
	{
		if (dot[i].x >= dRect.start.x&&dot[i].y >= dRect.start.y&&dot[i].x <= dRect.end.x&&dot[i].y <= dRect.end.y)
		{
			if (color_[i] == 0)
			{
				color_[i] = 255;
				d_dot++;
			}
		}
	}
	CWnd::OnRButtonUp(nFlags, point);
}


void CChildView::OnMouseMove(UINT nFlags, CPoint point)
{
	if (LBD)
	{
		dot[dot_num] = point;
		dot_num++;
	}
	if (RBD)
	{
		dRect.end = point;
	}
	Invalidate();
	CWnd::OnMouseMove(nFlags, point);
}
