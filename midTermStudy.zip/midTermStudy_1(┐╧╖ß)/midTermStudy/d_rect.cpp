#include"stdafx.h"
#include"d_rect.h"

DRect::DRect()
{
}

DRect::~DRect()
{
}