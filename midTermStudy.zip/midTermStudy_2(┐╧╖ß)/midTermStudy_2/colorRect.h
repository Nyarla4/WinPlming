#pragma once
class Rect
{
public:
	Rect();
	~Rect();
	CPoint start;
	CPoint end;
private:

};