
// ChildView.cpp : CChildView Ŭ������ ����
//

#include "stdafx.h"
#include "midTermStudy_2.h"
#include "ChildView.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// CChildView

CChildView::CChildView()
{
	rect_num = 0;
}

CChildView::~CChildView()
{
}


BEGIN_MESSAGE_MAP(CChildView, CWnd)
	ON_WM_PAINT()
	ON_WM_LBUTTONDOWN()
	ON_WM_LBUTTONUP()
	ON_WM_KEYDOWN()
END_MESSAGE_MAP()



// CChildView �޽��� ó����

BOOL CChildView::PreCreateWindow(CREATESTRUCT& cs) 
{
	if (!CWnd::PreCreateWindow(cs))
		return FALSE;

	cs.dwExStyle |= WS_EX_CLIENTEDGE;
	cs.style &= ~WS_BORDER;
	cs.lpszClass = AfxRegisterWndClass(CS_HREDRAW|CS_VREDRAW|CS_DBLCLKS, 
		::LoadCursor(NULL, IDC_ARROW), reinterpret_cast<HBRUSH>(COLOR_WINDOW+1), NULL);

	return TRUE;
}

void CChildView::OnPaint() 
{
	CPaintDC dc(this);
	
	for (int i = 0; i < rect_num; i++)
	{
		CBrush brush(RGB(color_r[i], color_g[i], color_b[i]));
		dc.SelectObject(&brush);
		dc.Rectangle(Rect[i].start.x, Rect[i].start.y, Rect[i].end.x, Rect[i].end.y);
	}
}



void CChildView::OnLButtonDown(UINT nFlags, CPoint point)
{
	Rect[rect_num].start = point;

	CWnd::OnLButtonDown(nFlags, point);
}


void CChildView::OnLButtonUp(UINT nFlags, CPoint point)
{
	Rect[rect_num].end = point;
	rect_num++;
	Invalidate();
	CWnd::OnLButtonUp(nFlags, point);
}


void CChildView::OnKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags)
{
	for (int j = 0; j < rect_num; j++)
	{
		int i = rect_num - 1;
		if (nChar == 'R')
		{
			color_r[i] = 255;
			color_g[i] = 0;
			color_b[i] = 0;
		}
		if (nChar == 'G')
		{
			color_r[i] = 0;
			color_g[i] = 255;
			color_b[i] = 0;
		}
		if (nChar == 'B')
		{
			color_r[i] = 0;
			color_g[i] = 0;
			color_b[i] = 255;
		}
	}
	Invalidate();
	CWnd::OnKeyDown(nChar, nRepCnt, nFlags);
}
