#include"stdafx.h"
#include"colorRect.h"

Rect::Rect()
{
}

Rect::~Rect()
{
}