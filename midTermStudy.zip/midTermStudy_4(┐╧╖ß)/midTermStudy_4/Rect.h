#pragma once
class w_rect
{
public:
	w_rect();
	~w_rect();

	CPoint start;
	CPoint end;
private:

};