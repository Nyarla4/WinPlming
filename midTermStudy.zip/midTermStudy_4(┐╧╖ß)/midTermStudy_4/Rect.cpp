#include"stdafx.h"
#include"Rect.h"

w_rect::w_rect()
{
}

w_rect::~w_rect()
{
}