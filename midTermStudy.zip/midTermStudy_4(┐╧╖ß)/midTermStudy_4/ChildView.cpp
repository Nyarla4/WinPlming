
// ChildView.cpp : CChildView Ŭ������ ����
//

#include "stdafx.h"
#include "midTermStudy_4.h"
#include "ChildView.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// CChildView

CChildView::CChildView()
{
	Rect.start.x = Rect.start.y = 100;
	Rect.end.x = 1000; Rect.end.y = 200;
	str_num = 0;
}

CChildView::~CChildView()
{
}


BEGIN_MESSAGE_MAP(CChildView, CWnd)
	ON_WM_PAINT()
	ON_WM_KEYDOWN()
END_MESSAGE_MAP()



// CChildView �޽��� ó����

BOOL CChildView::PreCreateWindow(CREATESTRUCT& cs) 
{
	if (!CWnd::PreCreateWindow(cs))
		return FALSE;

	cs.dwExStyle |= WS_EX_CLIENTEDGE;
	cs.style &= ~WS_BORDER;
	cs.lpszClass = AfxRegisterWndClass(CS_HREDRAW|CS_VREDRAW|CS_DBLCLKS, 
		::LoadCursor(NULL, IDC_ARROW), reinterpret_cast<HBRUSH>(COLOR_WINDOW+1), NULL);

	return TRUE;
}

void CChildView::OnPaint() 
{
	CPaintDC dc(this);
	dc.Rectangle(Rect.start.x,Rect.start.y,Rect.end.x,Rect.end.y);
	RECT rect = { Rect.start.x+1,Rect.start.y+1,Rect.end.x,Rect.end.y };
	dc.DrawText(str, &rect , DT_LEFT);
}



void CChildView::OnKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags)
{
	str_num = str.GetLength();
	if (nChar == VK_BACK)
		str.Delete(str_num - 1, 1);
	else
	{
		str_w.Format(_T("%c"), nChar);
		str += str_w;
	}

	Invalidate();
	CWnd::OnKeyDown(nChar, nRepCnt, nFlags);
}
