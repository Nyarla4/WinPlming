
// ChildView.cpp : CChildView Ŭ������ ����
//

#include "stdafx.h"
#include "180503.h"
#include "ChildView.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// CChildView

CChildView::CChildView()
{
}

CChildView::~CChildView()
{
}


BEGIN_MESSAGE_MAP(CChildView, CWnd)
	ON_WM_PAINT()
//	ON_COMMAND(AFX_ID_PREVIEW_CLOSE, &CChildView::OnColorRed)
ON_COMMAND(ID_COLOR_RED, &CChildView::OnColorRed)
ON_COMMAND(ID_COLOR_GREEN, &CChildView::OnColorGreen)
ON_COMMAND(ID_COLOR_BLUE, &CChildView::OnColorBlue)
ON_UPDATE_COMMAND_UI(ID_COLOR_RED, &CChildView::OnUpdateColorRed)
ON_UPDATE_COMMAND_UI(ID_COLOR_GREEN, &CChildView::OnUpdateColorGreen)
ON_UPDATE_COMMAND_UI(ID_COLOR_BLUE, &CChildView::OnUpdateColorBlue)
END_MESSAGE_MAP()



// CChildView �޽��� ó����

BOOL CChildView::PreCreateWindow(CREATESTRUCT& cs) 
{
	if (!CWnd::PreCreateWindow(cs))
		return FALSE;

	cs.dwExStyle |= WS_EX_CLIENTEDGE;
	cs.style &= ~WS_BORDER;
	cs.lpszClass = AfxRegisterWndClass(CS_HREDRAW|CS_VREDRAW|CS_DBLCLKS, 
		::LoadCursor(NULL, IDC_ARROW), reinterpret_cast<HBRUSH>(COLOR_WINDOW+1), NULL);

	return TRUE;
}

void CChildView::OnPaint() 
{
	CPaintDC dc(this); 

	CBrush brush(color);
	dc.SelectObject(&brush);
	dc.Rectangle(100, 100, 200, 200);
}



//void CChildView::OnColorRed()
//{
//	color = RGB(255, 0, 0);
//	Invalidate();
//}

void CChildView::OnColorRed()
{
	color = RGB(255, 0, 0);
	Invalidate();
}


void CChildView::OnColorGreen()
{
	color = RGB(0, 255, 0);
	Invalidate();
}


void CChildView::OnColorBlue()
{
	color = RGB(0, 0, 255);
	Invalidate();
}


void CChildView::OnUpdateColorRed(CCmdUI *pCmdUI)
{
	if (color == RGB(255, 0, 0))
		pCmdUI->SetCheck(true);
	else
		pCmdUI->SetCheck(false);
}


void CChildView::OnUpdateColorGreen(CCmdUI *pCmdUI)
{
	if (color == RGB(0, 255, 0))
		pCmdUI->SetCheck(true);
	else
		pCmdUI->SetCheck(false);
}


void CChildView::OnUpdateColorBlue(CCmdUI *pCmdUI)
{
	if (color == RGB(0, 0, 255))
		pCmdUI->SetCheck(true);
	else
		pCmdUI->SetCheck(false);
}
