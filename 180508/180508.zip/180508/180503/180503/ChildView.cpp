
// ChildView.cpp : CChildView Ŭ������ ����
//

#include "stdafx.h"
#include "180503.h"
#include "ChildView.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// CChildView

CChildView::CChildView()
{
	basic = true;
	sel_rec = false;
	sel_ell = false;
}

CChildView::~CChildView()
{
}


BEGIN_MESSAGE_MAP(CChildView, CWnd)
	ON_WM_PAINT()
//	ON_COMMAND(AFX_ID_PREVIEW_CLOSE, &CChildView::OnColorRed)
ON_COMMAND(ID_COLOR_RED, &CChildView::OnColorRed)
ON_COMMAND(ID_COLOR_GREEN, &CChildView::OnColorGreen)
ON_COMMAND(ID_COLOR_BLUE, &CChildView::OnColorBlue)
ON_UPDATE_COMMAND_UI(ID_COLOR_RED, &CChildView::OnUpdateColorRed)
ON_UPDATE_COMMAND_UI(ID_COLOR_GREEN, &CChildView::OnUpdateColorGreen)
ON_UPDATE_COMMAND_UI(ID_COLOR_BLUE, &CChildView::OnUpdateColorBlue)
ON_WM_CONTEXTMENU()
//ON_COMMAND(ID_BUTTON32778, &CChildView::OnButton32778)
ON_COMMAND(ID_SEL_REC, &CChildView::OnSelRec)
ON_COMMAND(ID_SEL_ELL, &CChildView::OnSelEll)
END_MESSAGE_MAP()



// CChildView �޽��� ó����

BOOL CChildView::PreCreateWindow(CREATESTRUCT& cs) 
{
	if (!CWnd::PreCreateWindow(cs))
		return FALSE;

	cs.dwExStyle |= WS_EX_CLIENTEDGE;
	cs.style &= ~WS_BORDER;
	cs.lpszClass = AfxRegisterWndClass(CS_HREDRAW|CS_VREDRAW|CS_DBLCLKS, 
		::LoadCursor(NULL, IDC_ARROW), reinterpret_cast<HBRUSH>(COLOR_WINDOW+1), NULL);

	return TRUE;
}

void CChildView::OnPaint() 
{
	CPaintDC dc(this); 

	CBrush brush(color);
	dc.SelectObject(&brush);
	if (basic)
	{
		dc.Rectangle(100, 100, 200, 200);
	}
	if (sel_rec)
	{
		dc.Rectangle(100, 100, 300, 300);
	}
	else if (sel_ell)
	{
		dc.Ellipse(100, 100, 300, 300);
	}
}



//void CChildView::OnColorRed()
//{
//	color = RGB(255, 0, 0);
//	Invalidate();
//}

void CChildView::OnColorRed()
{
	color = RGB(255, 100, 100);
	Invalidate();
}


void CChildView::OnColorGreen()
{
	color = RGB(100, 255, 100);
	Invalidate();
}


void CChildView::OnColorBlue()
{
	color = RGB(100, 100, 255);
	Invalidate();
}


void CChildView::OnUpdateColorRed(CCmdUI *pCmdUI)//C Comand UI
{
	if (color == RGB(255, 100, 100))
		pCmdUI->SetCheck(true);//üũ�ϴ°ſ� true
	else
		pCmdUI->SetCheck(false);
	//invalidate()�ʿ�X, Ŭ���̾�Ʈ ������ �ƴϹǷ�
}


void CChildView::OnUpdateColorGreen(CCmdUI *pCmdUI)
{
	if (color == RGB(100, 255, 100))
		pCmdUI->SetCheck(true);
	else
		pCmdUI->SetCheck(false);
}


void CChildView::OnUpdateColorBlue(CCmdUI *pCmdUI)
{
	if (color == RGB(100, 100, 255))
		pCmdUI->SetCheck(true);
	else
		pCmdUI->SetCheck(false);
}


void CChildView::OnContextMenu(CWnd* pWnd, CPoint point)
{
	//AfxMessageBox(_T("���ؽ�Ʈ �޴�"));
	/*
	CMenu menuPopup;//�޴� ����
	menuPopup.CreatePopupMenu();//�޴� �������(������)
	menuPopup.AppendMenu(MF_STRING, 201, _T("Red (&R)"));//�޴� ���� ����
	menuPopup.AppendMenu(MF_STRING, 202, _T("Green (&G)"));//����:ID
	menuPopup.AppendMenu(MF_STRING, 203, _T("Blue (&B)"));
	menuPopup.TrackPopupMenu(
			TPM_LEFTALIGN | TPM_LEFTBUTTON,
			point.x, point.y,//���� ���콺 ��ġ�� ���δ�
			AfxGetMainWnd());
	*/
	CMenu menu;
	menu.LoadMenu(IDR_MAINFRAME);//���� �۵��ϴ� �޴����� �ҷ���
	CMenu* pMenu = menu.GetSubMenu(4);//���� �޴��� ���� �޴��� 4��°(color)�� ������
	pMenu->TrackPopupMenu(
		TPM_LEFTALIGN | TPM_RIGHTBUTTON,
		point.x, point.y, AfxGetMainWnd());
}


void CChildView::OnSelRec()
{
	basic = false;
	sel_ell = false;
	sel_rec = true;
	Invalidate();
}


void CChildView::OnSelEll()
{
	basic = false;
	sel_rec = false;
	sel_ell = true;
	Invalidate();
}
