//{{NO_DEPENDENCIES}}
// Microsoft Visual C++���� ������ ���� �����Դϴ�.
// 180531.rc���� ���ǰ� �ֽ��ϴ�.
//
#define IDD_ABOUTBOX                    100
#define IDR_MAINFRAME                   128
#define IDR_My180531TYPE                130
#define IDD_DIALOG1                     310
#define IDD_DIALOG2                     312
#define IDC_EDIT1                       1000
#define IDC_RadioRed                    1001
#define IDC_RadioGreen                  1002
#define IDC_RADIO3                      1003
#define IDC_RadioBlue                   1003
#define IDC_RADIOB                      1003
#define IDC_RADIOR                      1004
#define IDC_RADIOG                      1005
#define IDC_BUTTON1                     1006
#define IDC_ButtonColor                 1006

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        314
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1007
#define _APS_NEXT_SYMED_VALUE           310
#endif
#endif
