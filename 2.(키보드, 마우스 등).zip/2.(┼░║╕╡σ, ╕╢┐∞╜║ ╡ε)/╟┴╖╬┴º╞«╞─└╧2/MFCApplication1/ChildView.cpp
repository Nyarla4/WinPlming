
// ChildView.cpp : CChildView Ŭ������ ����
//

#include "stdafx.h"
#include "MFCApplication1.h"
#include "ChildView.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// CChildView

CChildView::CChildView()
{
}

CChildView::~CChildView()
{
}


BEGIN_MESSAGE_MAP(CChildView, CWnd)
	ON_WM_PAINT()
	ON_WM_LBUTTONDOWN()
	ON_WM_LBUTTONUP()
	ON_WM_MOUSEMOVE()
	ON_WM_KEYDOWN()
END_MESSAGE_MAP()



// CChildView �޽��� ó����

BOOL CChildView::PreCreateWindow(CREATESTRUCT& cs) 
{
	if (!CWnd::PreCreateWindow(cs))
		return FALSE;

	cs.dwExStyle |= WS_EX_CLIENTEDGE;
	cs.style &= ~WS_BORDER;
	cs.lpszClass = AfxRegisterWndClass(CS_HREDRAW|CS_VREDRAW|CS_DBLCLKS, 
		::LoadCursor(NULL, IDC_ARROW), reinterpret_cast<HBRUSH>(COLOR_WINDOW+1), NULL);

	return TRUE;
}

void CChildView::OnPaint() 
{
	CPaintDC dc(this);
	/*dc.MoveTo(m_pt0);
	dc.LineTo(m_pt1);*/
	dc.Rectangle(m_pt.x, m_pt.y, m_pt.x+100,m_pt.y+100);
}


void CChildView::OnLButtonDown(UINT nFlags, CPoint point)
{
	
	/*LBD = true;
	m_pt0 = point;
	CWnd::OnLButtonDown(nFlags, point);*/
}

void CChildView::OnLButtonUp(UINT nFlags, CPoint point)
{
	/*LBD = false;
	m_pt1 = point;
	CWnd::OnLButtonUp(nFlags, point);
	Invalidate();//��ȿ���� ���� ��ȿȭ(�Ƹ�)*/
}


void CChildView::OnMouseMove(UINT nFlags, CPoint point)
{
		/*if (LBD)
		{
			m_pt1 = point;
		}
		Invalidate();
		CWnd::OnMouseMove(nFlags, point);*/
}

void CChildView::OnKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags)
{
	switch (nChar)
	{
	case VK_RIGHT:
		m_pt.x += 10;
		break;
	case VK_LEFT:
		m_pt.x -= 10;
		break;
	case VK_UP:
		m_pt.y -= 10;
		break;
	case VK_DOWN:
		m_pt.y += 10;
		break;
	default:
		break;
	}
	Invalidate();
	CWnd::OnKeyDown(nChar, nRepCnt, nFlags);
}
