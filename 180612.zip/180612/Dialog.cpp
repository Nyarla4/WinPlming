// Dialog.cpp : ���� �����Դϴ�.
//

#include "stdafx.h"
#include "180612.h"
#include "Dialog.h"
#include "afxdialogex.h"
#include"ChildView.h"


// Dialog ��ȭ �����Դϴ�.

IMPLEMENT_DYNAMIC(Dialog, CDialog)

Dialog::Dialog(CWnd* pParent /*=NULL*/)
	: CDialog(IDD_DIALOG1, pParent)
{

}

Dialog::~Dialog()
{
}

void Dialog::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_BUTTON1, button1);
	DDX_Control(pDX, IDC_BUTTON2, button2);
	DDX_Control(pDX, IDC_BUTTON3, button3);
	DDX_Control(pDX, IDC_BUTTONP, buttonP);
	DDX_Control(pDX, IDC_BUTTONM, buttonM);
	DDX_Control(pDX, IDC_BUTTONE, buttonE);
	DDX_Control(pDX, IDC_BUTTONC, buttonC);
}


BEGIN_MESSAGE_MAP(Dialog, CDialog)
	ON_BN_CLICKED(IDC_BUTTON1, &Dialog::OnClickedButton1)
	ON_BN_CLICKED(IDC_BUTTON2, &Dialog::OnClickedButton2)
	ON_BN_CLICKED(IDC_BUTTON3, &Dialog::OnClickedButton3)
	ON_BN_CLICKED(IDC_BUTTONP, &Dialog::OnClickedButtonp)
	ON_BN_CLICKED(IDC_BUTTONM, &Dialog::OnClickedButtonm)
	ON_BN_CLICKED(IDC_BUTTONE, &Dialog::OnClickedButtone)
	ON_BN_CLICKED(IDC_BUTTONC, &Dialog::OnClickedButtonc)
END_MESSAGE_MAP()


// Dialog �޽��� ó�����Դϴ�.


void Dialog::OnClickedButton1()
{
	str += '1';

}


void Dialog::OnClickedButton2()
{
	str += '2';
}


void Dialog::OnClickedButton3()
{
	str += '3';
}


void Dialog::OnClickedButtonp()
{
	str += '+';
}


void Dialog::OnClickedButtonm()
{
	str += '-';
}


void Dialog::OnClickedButtone()
{
	str += '=';
}


void Dialog::OnClickedButtonc()
{
	str.Remove('1');
	str.Remove('2');
	str.Remove('3');
	str.Remove('4');
	str.Remove('5');
	str.Remove('6');
	str.Remove('7');
	str.Remove('8');
	str.Remove('9');
	str.Remove('0');
	str.Remove('+');
	str.Remove('-');
	str.Remove('=');
}
