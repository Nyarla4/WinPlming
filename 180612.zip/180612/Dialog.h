#pragma once
#include "afxwin.h"
class ChildView;


// Dialog ��ȭ �����Դϴ�.

class Dialog : public CDialog
{
	DECLARE_DYNAMIC(Dialog)

public:
	Dialog(CWnd* pParent = NULL);   // ǥ�� �������Դϴ�.
	virtual ~Dialog();

// ��ȭ ���� �������Դϴ�.
#ifdef AFX_DESIGN_TIME
	enum { IDD = IDD_DIALOG1 };
#endif

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV �����Դϴ�.

	DECLARE_MESSAGE_MAP()
public:
	CString str;
	int number;
	ChildView *p_view;


	CButton button1;
	CButton button2;
	CButton button3;
	CButton buttonP;
	CButton buttonM;
	CButton buttonE;
	CButton buttonC;
	afx_msg void OnClickedButton1();
	afx_msg void OnClickedButton2();
	afx_msg void OnClickedButton3();
	afx_msg void OnClickedButtonp();
	afx_msg void OnClickedButtonm();
	afx_msg void OnClickedButtone();
	afx_msg void OnClickedButtonc();
};
