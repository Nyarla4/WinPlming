
// ChildView.cpp : CChildView Ŭ������ ����
//

#include "stdafx.h"
#include "180531.h"
#include "ChildView.h"
#include"Dialog.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// CChildView

CChildView::CChildView()
{
	str.Format(_T("test"));
	col = 0;
}

CChildView::~CChildView()
{
}


BEGIN_MESSAGE_MAP(CChildView, CWnd)
	ON_WM_PAINT()
	ON_WM_RBUTTONDOWN()
END_MESSAGE_MAP()



// CChildView �޽��� ó����

BOOL CChildView::PreCreateWindow(CREATESTRUCT& cs) 
{
	if (!CWnd::PreCreateWindow(cs))
		return FALSE;

	cs.dwExStyle |= WS_EX_CLIENTEDGE;
	cs.style &= ~WS_BORDER;
	cs.lpszClass = AfxRegisterWndClass(CS_HREDRAW|CS_VREDRAW|CS_DBLCLKS, 
		::LoadCursor(NULL, IDC_ARROW), reinterpret_cast<HBRUSH>(COLOR_WINDOW+1), NULL);

	return TRUE;
}

void CChildView::OnPaint() 
{
	CPaintDC dc(this);

	CRect rect(100, 100, 300, 300);

	CBrush bru(RGB(0, 0, 0));
	dc.Rectangle(rect);
		
	dc.DrawText(str, rect, DT_LEFT);
}

COLORREF cR = RGB(255, 0, 0), cG = RGB(0, 255, 0), cB = RGB(0, 0, 255);


void CChildView::OnRButtonDown(UINT nFlags, CPoint point)
{
	Dialog dlg;
	
	dlg.m_str = str;
	dlg.m_color = col;

	if (dlg.DoModal() != IDOK)
		return;

	str = dlg.m_str;
	col = dlg.m_color;

	Invalidate();
	CWnd::OnRButtonDown(nFlags, point);
}
